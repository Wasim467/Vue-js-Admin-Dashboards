<template>
  <default-dashboard />
</template>

<script>
import DefaultDashboard from "@/views/dashboards/Default.vue";

export default {
  name: "HomePage",
  components: {
    DefaultDashboard,
  },
};
</script>
